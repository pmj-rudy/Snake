/**
 * 
 */
/**
 * @author LENOVO
 *
 */
module ̰ʳ�� {
	requires java.desktop;
}